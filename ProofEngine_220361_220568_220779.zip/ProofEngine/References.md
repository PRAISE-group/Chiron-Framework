### For PrefixConvertor: 
- AST visitor template : https://gist.github.com/jtpio/cb30bca7abeceae0234c9ef43eec28b4
- AST Documentation : https://docs.python.org/3/library/ast.html#ast.NodeVisitor.visit
- SMTLIB Documentation : https://smt-lib.org/