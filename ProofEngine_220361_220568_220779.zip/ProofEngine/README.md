Following files are concerned with each milestone - 
Milestone 1 : ConstraintParser.py, main.py, PrefixConvertor.py, SMTLIBConvertor.py, `tests` folder.
Milestone 2 : IrToSmtlib.py, some changes have been made in `../ChironCore/chiron.py` file.

Report for these milestones is in the `Docs` folder with the name `Report1.pdf`.

All the changes are pushed on our forked branch of the original Chiron repository. Kindly refer to the forked repository to view the complete folder structure - [text](https://github.com/dhruvgupta22/ProofEngine)

Authors : 
- Dhruv Gupta (220361)
- Kundan Kumar (220568)
- Pragati Agrawal (220779)